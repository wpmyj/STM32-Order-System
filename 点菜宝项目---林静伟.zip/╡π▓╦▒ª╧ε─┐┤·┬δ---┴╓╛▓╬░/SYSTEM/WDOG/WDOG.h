#ifndef _WDOG_H_
#define _WDOG_H_
#include <stm32f10x.h>
#include "sys.h"

void W_WDG_Init(u16 w_arr, u16 arr, u16 psc);

#endif

